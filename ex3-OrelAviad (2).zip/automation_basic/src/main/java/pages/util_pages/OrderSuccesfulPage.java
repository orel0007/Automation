package pages.util_pages;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import pages._pages_mngt.MainPageManager;
import pages.super_pages.MenusPage;
import util.GenUtils;

public class OrderSuccesfulPage extends CheckOutPage {

	public OrderSuccesfulPage(MainPageManager pages) {
		super(pages);
	}
	
	public OrderSuccesfulPage ensurePageLoaded() {
		super.ensurePageLoaded();
		waitBig.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//div[@class='page-title']/h1"))));
		return this;
	}
	
	public OrderSuccesfulPage checkOrderSuccesfulPage() {
		log.info("Check that proper confirmation text has been received");
		GenUtils.sleepMillis(2000);
		String confirmText1 = "Thank you";
		String confirmText2 = "Your order has been successfully processed!";
		String receivedText1 = driver.findElement(By.xpath("//div[@class='page-title']/h1")).getText();
		String receivedText2 = driver.findElement(By.xpath("//div[@class='title']/strong")).getText();
		Assert.assertTrue(confirmText1.equals(receivedText1),
				"Expected text is " + confirmText1 + " but instead received " + receivedText1);
		Assert.assertTrue(confirmText2.equals(receivedText2),
				"Expected text is " + confirmText2 + " but instead received " + receivedText2);
		return this;
	}
	
	public MenusPage clickConfirmOrder() {
		log.info("click continue");
		driver.findElement(By.cssSelector(".order-completed-continue-button")).click();
		return pages.menusPage.ensurePageLoaded();
	}
	
}
