package pages.util_pages;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import pages._pages_mngt.MainPageManager;
import util.GenUtils;

public class CheckOutPage extends ShoopingCartPage{
	public CheckOutPage(MainPageManager pages) {
		super(pages);
	}
	
	public CheckOutPage ensurePageLoaded() {
		super.ensurePageLoaded();
		waitBig.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//div[@class = 'page-title']//h1"))));
		return this;
	}
	
	public CheckOutPage insertCountry(String countrName) {
		log.info("Enter country " + countrName);
		Select country = new Select(driver.findElement(By.id("BillingNewAddress_CountryId")));
		country.selectByVisibleText(countrName);
		return this;
	}
	
	public CheckOutPage insertState(String stateName) {//if choose united states but i choosed israel
		log.info("Enter state " + stateName);
		Select state = new Select(driver.findElement(By.id("BillingNewAddress_StateProvinceId")));
		state.selectByVisibleText(stateName);
		return this;
	}
	
	public CheckOutPage inserDeatilas(String city, String Address1,String ZipPostalCode, String PhoneNumber) {
		log.info("Enter Details");
		driver.findElement(By.id("BillingNewAddress_City")).sendKeys(city);
		driver.findElement(By.id("BillingNewAddress_Address1")).sendKeys(Address1);
		driver.findElement(By.id("BillingNewAddress_ZipPostalCode")).sendKeys(ZipPostalCode);
		driver.findElement(By.id("BillingNewAddress_PhoneNumber")).sendKeys(PhoneNumber);
		driver.findElement(By.cssSelector(".new-address-next-step-button:nth-child(1)")).click();
		return this;
	}
	
	public CheckOutPage acceptShipingMethod() {
		log.info("Accept current shipping method");
		GenUtils.sleepMillis(2000);
		driver.findElement(By.cssSelector(".shipping-method-next-step-button")).click();
		return this;
	}

	public CheckOutPage acceptPayment() {
		log.info("Accept payment method");
		waitBig.until(ExpectedConditions.visibilityOf(driver.findElement(By.cssSelector(".payment-method-next-step-button"))));
		driver.findElement(By.cssSelector(".payment-method-next-step-button")).click();
		return this;
	}
	
	public CheckOutPage acceptAdress() {
		//add wait
		log.info("Accept address confirmation");
		waitBig.until(ExpectedConditions.visibilityOf(driver.findElement(By.cssSelector(".payment-info-next-step-button"))));
		driver.findElement(By.cssSelector(".payment-info-next-step-button")).click();
		return this;
	}
	
	public CheckOutPage checkOrederTotalSameAsSinglePagePrice(String price) {
		//add wait
		log.info("Check order total and confirm order");
		GenUtils.sleepMillis(2000);
		String checkoutPrice = driver.findElement(By.xpath("//span[@class='product-subtotal']")).getText();
		Assert.assertTrue(price.toString().equals(checkoutPrice),
				"Expected price is " + price.toString() + " but the price on the checkout page is " + checkoutPrice);
		return this;
	}
	
	public OrderSuccesfulPage clickConfirm() {
		//add wait
		log.info("Check that proper confirmation text has been received and click continue");
		waitBig.until(ExpectedConditions.visibilityOf(driver.findElement(By.cssSelector(".confirm-order-next-step-button"))));
		driver.findElement(By.cssSelector(".confirm-order-next-step-button")).click();
		return pages.orderSuccesfulPage.ensurePageLoaded();
	}
}
