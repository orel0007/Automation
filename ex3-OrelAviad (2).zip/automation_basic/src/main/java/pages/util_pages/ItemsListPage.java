package pages.util_pages;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import pages._pages_mngt.MainPageManager;
import util.GenUtils;

public class ItemsListPage extends CategoryContentPage{
	public ItemsListPage(MainPageManager pages) {
		super(pages);
	}

	public ItemsListPage ensurePageLoaded() {
		super.ensurePageLoaded();
		waitBig.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//div[@class ='page-title']//h1"))));
		return this;
	}
	
	public SingleItemPage clickChooseItem() {
		log.debug("go to singleItemPage");
		driver.findElement(By.xpath("//input[@class='button-2 product-box-add-to-cart-button']")).click();
		return pages.singleItemPage.ensurePageLoaded();
	}
}