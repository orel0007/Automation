package pages.util_pages;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import pages._pages_mngt.MainPageManager;
import pages.super_pages.MenusPage;
import util.GenUtils;

public class CategoryContentPage extends MenusPage {

	public CategoryContentPage(MainPageManager pages) {
		super(pages);
	}
	
	public CategoryContentPage ensurePageLoaded() {
		super.ensurePageLoaded();
		waitBig.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//div[@class ='page-title']//h1"))));
		return this;
	}
	
	public ItemsListPage clickChoosenContent(String content) {		
		log.info("Go to the '" + content + "' content");
		driver.findElement(By.linkText(content)).click();
		return pages.itemsListPage.ensurePageLoaded();
	}
}
