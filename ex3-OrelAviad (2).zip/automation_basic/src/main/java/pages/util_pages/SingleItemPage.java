package pages.util_pages;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;

import pages._pages_mngt.MainPageManager;
import pages.super_pages.MenusPage;
import util.GenUtils;

public class SingleItemPage extends ItemsListPage{
	public SingleItemPage(MainPageManager pages) {
		super(pages);
	}

	public SingleItemPage ensurePageLoaded() {
		super.ensurePageLoaded();
		GenUtils.sleepMillis(2000);
		//waitBig.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//div[@class='product-name']/h1"))));
		return this;
	}
	
	public String getItemPrice() {
		String priceItem = (driver.findElement(By.xpath("//span[@class='price-value-25']")).getText());
		log.debug("The price is " + priceItem);
		return priceItem;
	}
	
	public MenusPage clickAddCart() {
		log.info("Click add cart");
		driver.findElement(By.id("add-to-cart-button-25")).click();		
		return pages.menusPage.ensurePageLoaded();
	}	
}
