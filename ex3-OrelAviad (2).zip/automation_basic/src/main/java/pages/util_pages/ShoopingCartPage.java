package pages.util_pages;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import pages._pages_mngt.MainPageManager;
import util.GenUtils;

public class ShoopingCartPage extends CategoryContentPage{
	public ShoopingCartPage(MainPageManager pages) {
		super(pages);
		// TODO Auto-generated constructor stub
	}
	
	public ShoopingCartPage ensurePageLoaded() {
		super.ensurePageLoaded();
		waitBig.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//div[@class ='page-title']//h1"))));
		return this;
	}
	
	public ShoopingCartPage checkCartPrice(String price) {	
		GenUtils.sleepMillis(6000);//we need to wait for the cart apdate item is add
 		String cartPrice = driver.findElement(By.xpath("//span[@class='value-summary']/strong")).getText();
		log.info("cart price is: " + cartPrice);
		Assert.assertTrue(price.toString().equals(cartPrice),
				"Expected price is " + price + " but the price in the cart is " + cartPrice);
		return this;
	}
	
	public ShoopingCartPage sighnTermOfUseBox() {	
		log.info("Click on box verification if not already clicked");
		if (!driver.findElement(By.id("termsofservice")).isSelected())
			driver.findElement(By.id("termsofservice")).click();
		return this;
	}
	
	public CheckOutPage clickCheckOut() {	
		log.info("Click on 'checkout' button");
		driver.findElement(By.id("checkout")).click();
		return pages.checkOutPage.ensurePageLoaded();
	}
	
	

}
