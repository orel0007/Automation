package pages.super_pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import pages._pages_mngt.MainPageManager;
import pages.util_pages.CategoryContentPage;
import pages.util_pages.HomePage;
import pages.util_pages.ItemsListPage;
import pages.util_pages.LoginPage;
import pages.util_pages.RegisterPage;
import pages.util_pages.ShoopingCartPage;
import util.GenUtils;

public class MenusPage extends AnyPage {

	@FindBy(xpath = "//a[@class='ico-logout']")
	private WebElement logoutLink;


	public MenusPage(MainPageManager pages) {
		super(pages);
	}

	public MenusPage ensurePageLoaded() {
		super.ensurePageLoaded();
		waitBig.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("body")));
		return this;
	}

	public RegisterPage clickRegister() {
		log.info("Click Register link.");
		driver.findElement(By.linkText("Register")).click();
		return pages.registerPage.ensurePageLoaded();
	}

	public HomePage logout() {
		log.info("Click logout button");
		logoutLink.click();
		return pages.homePage.ensurePageLoaded();
	}

	public LoginPage clickLogin() {
		log.info("Click login button");
		driver.findElement(By.linkText("Log in")).click();
		return pages.loginPage;
	}
	
	public CategoryContentPage clickChoosenCategory(String category) {
		log.info("Go to the '"+ category +"' category");
		driver.findElement(By.linkText(category)).click();	
		return pages.categoryContentPage.ensurePageLoaded();
	}
	
	public MenusPage checkAmountItemsInCart(String sumOfElementsInShoopingCart) {
		log.info("Check correct sum of items in cart is equal to: " + sumOfElementsInShoopingCart);
		String expectedCartAmount = sumOfElementsInShoopingCart;
		GenUtils.sleepMillis(6000);
		String cartAmount = driver.findElement(By.xpath("//span[@class='cart-qty']")).getText();
		Assert.assertTrue(cartAmount.equals(expectedCartAmount),
				"Expected cart amount to be " + expectedCartAmount + " but received " + cartAmount + " instead.");	
		return this;
	}

	public ShoopingCartPage clickGoToCart() {
		log.info("Go to cart and move to shoopingCartPage");
		driver.findElement(By.cssSelector(".cart-label")).click();			
		return pages.shoopingCartPage.ensurePageLoaded();
	}
}